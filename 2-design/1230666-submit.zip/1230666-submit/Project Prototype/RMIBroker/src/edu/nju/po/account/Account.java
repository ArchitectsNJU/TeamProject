package edu.nju.po.account;

import java.io.Serializable;

public class Account implements Serializable {

}
