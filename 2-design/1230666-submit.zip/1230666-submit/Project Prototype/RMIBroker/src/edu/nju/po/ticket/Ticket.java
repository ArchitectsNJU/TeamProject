package edu.nju.po.ticket;

import java.io.Serializable;

public class Ticket implements Serializable{

}
