package edu.nju.po.schedule;

import java.io.Serializable;

public class Route implements Serializable {
}
