package edu.nju.po.schedule;

import java.io.Serializable;

public class ScheduleFilter implements Serializable {

}
