package edu.nju.po.common;

import java.io.Serializable;

public class OperationResult implements Serializable {

}
