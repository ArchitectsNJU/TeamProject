package edu.nju.po.schedule;

import java.io.Serializable;

public class Schedule implements Serializable {

}
