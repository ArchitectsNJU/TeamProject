package edu.nju.po.ticket;

import java.io.Serializable;

public class Passenger implements Serializable {

}
