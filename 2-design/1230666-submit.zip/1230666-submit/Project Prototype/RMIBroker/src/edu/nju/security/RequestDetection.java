package edu.nju.security;

import edu.nju.broker.model.Request;
import edu.nju.broker.model.Response;

public class RequestDetection implements SecurityIntercepter{

	@Override
	public void preHandle(Request request, Response response) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void postHandle(Request request, Response reponse) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void afterCompletion(Request request, Response reponse) {
		// TODO Auto-generated method stub
		
	}



}
