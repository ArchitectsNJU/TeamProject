package edu.nju.broker.model;

public class Result {

}
