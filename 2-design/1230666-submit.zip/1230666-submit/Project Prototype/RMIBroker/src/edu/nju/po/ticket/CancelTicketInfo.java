package edu.nju.po.ticket;

import java.io.Serializable;

public class CancelTicketInfo implements Serializable {

}
